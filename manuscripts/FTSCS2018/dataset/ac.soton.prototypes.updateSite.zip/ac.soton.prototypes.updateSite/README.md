# Features #
1. *org.eventb.emf.feature/sdk*  Event=B EMF Framework
2. *ac.soton.emf.translator.feature/sdk* EMF Translator
3. *ac.soon.emf.event.translator.feature/sdk* Adaptation of EMF Translator for Event-B
4. *ac.soton.eventb.emf.core.extensions.feature/sdk* Event-B EMF Support for Modelling Extensions (for Rodin 3.x)
5. *ac.soton.eventb.emf.diagrams.feature/sdk* Event-B GMF Support for Diagrams (for Rodin 3.x)
6. *ac.soton.eventb.emf.oracle.feature* Oracle feature
7. *ac.soton.eventb.statemachines.feature/sdk* iUML-B Statemachines (for Rodin 3.x.x)
8. *ac.soton.eventb.emf.inclusion.feature/tests/sdk* EMF Inclusion
9. *ac.soton.eventb.emf.decompsotion.feature* SharedEvent Decompositon based on defining regions (for Rodin 3.x.x)
10. *ac.soton.eventb.components.feature* Component Diagrams (for Rodin 3.2.x)
11. *ac.soton.coda.ui.feature* CODA User Interface.
12. *ac.soton.coda.simulator.feature* CODA Simulator for component diagrams for Rodin 3.1.x
